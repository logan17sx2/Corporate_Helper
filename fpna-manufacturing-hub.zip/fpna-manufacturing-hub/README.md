# FP&A Manufacturing Hub

Toolkit for financial analysts in manufacturing.